import React from 'react'

type Props = {}

const Practica16 = (props: Props) => {
  return (
    <div>Practica16</div>
  )
}

export default Practica16