<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ImgController extends Controller{
    public function showImg(){
        //$date = ;
        //$arr[0] = $date;
        return view('img');
    }
}
