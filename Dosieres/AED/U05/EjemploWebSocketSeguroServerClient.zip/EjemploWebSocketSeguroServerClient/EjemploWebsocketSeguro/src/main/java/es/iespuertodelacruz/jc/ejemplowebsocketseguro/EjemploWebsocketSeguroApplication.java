package es.iespuertodelacruz.jc.ejemplowebsocketseguro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploWebsocketSeguroApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploWebsocketSeguroApplication.class, args);
	}

}
