<?php
    namespace App\Contracts;

    class UserContract{
        public const TABLE_NAME="usuarios";
        public const COL_ID="id";
        public const COL_NICK="nick";
        public const COL_PSSWRD="password";
    }
?>