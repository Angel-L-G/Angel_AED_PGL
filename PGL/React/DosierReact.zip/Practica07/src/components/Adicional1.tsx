import React from 'react'

function Adicional1() {
    let arr: string[] = ["a","e","i","o","u"];

    return (
        <>
            {
                /*arr.map(m) => {
                    return (
                        <h3> {m} </h3>
                    );
                }*/
            }
        </>
    )
            }

export default Adicional1