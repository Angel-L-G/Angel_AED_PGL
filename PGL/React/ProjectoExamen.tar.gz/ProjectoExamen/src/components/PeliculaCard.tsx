import React, { useState } from 'react'
import UseDetallePelicula from '../hooks/UseDetallePelicula'
import { GiArmorDowngrade } from "react-icons/gi";
import { GiArmorUpgrade } from "react-icons/gi";
import { useAppContext } from './AppContextProvider';
import UsePeliculaCard from '../hooks/UsePeliculaCard';
import ReactPlayer from 'react-player';

type Pelicula = {
    id: string,
    titulo: string,
    direccion: string,
    actores: string,
    argumento: string,
    imagen: string,
    video: string,
    categoria: string
}

type Props = {
   peli: Pelicula,
   indiv?: number
}

const PeliculaCard = (props: Props) => {
    let {setPeliculaFavorito, favorito} = UsePeliculaCard();
    return (
        <div>
            <a href={'/pelicula/'+props.peli.id}>
                <img src={"http://localhost:3000/"+props.peli.imagen}/>
                <h1>{props.peli.titulo}</h1><br />
                <p>{props.peli.direccion}</p><br />
                <p>{props.peli.actores}</p><br />
                <p>{props.peli.argumento}</p><br />
                <p>{props.peli.categoria}</p><br />
                <ReactPlayer
                    url={props.peli.video}
                    controls
                    width="300px"
                    height="300px"
                />
                
            </a>
            <button onClick={() => setPeliculaFavorito(props.peli)}>
                {
                    (favorito)
                    ?<GiArmorUpgrade style={{color: "white",backgroundColor: "rgb(34, 17, 185)", height: 75, width: 75}}/>
                    :<GiArmorDowngrade style={{color: "white",backgroundColor: "rgb(34, 17, 185)", height: 75, width: 75}}/>
                }
                </button>
        </div>
    )
}

export default PeliculaCard