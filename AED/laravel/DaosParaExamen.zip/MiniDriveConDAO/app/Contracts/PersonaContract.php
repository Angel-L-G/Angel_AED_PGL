<?php
namespace App\Contracts;
    class PersonaContract{
        public const TABLE_NAME="personas";
        public const COL_ID="id";
        public const COL_NOMBRE="nombre";
        public const COL_EDAD="edad";
    }
?>
