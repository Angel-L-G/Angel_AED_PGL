<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">

    </head>
    <body class="antialiased">
        <div class="container">
            <div>
                <h2>Agregar Matricula</h2>
                <form action="createMatr" method="post">
                    <label>Year:</label><input type="text" id="year" name="year"><br/>
                    <label>Dni Alumno:</label><input type="text" id="dni" name="dni"><br/>
                    <?php $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label><?php echo e($a->getNombre()); ?></label>
                        <input type="checkbox" name="asignaturas[]" id="asignaturas[]" value=<?php echo e($a->getId()); ?>/><!--Esto funciona-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br/><label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <div>
                <h2>Borrar Matricula</h2>
                <form action="deleteMatr" method="post">
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <div>
                <h2>Editar Matricula</h2>
                <form action="updateMatr" method="post">
                    <label>Year:</label><input type="text" id="year" name="year"><br/>
                    <label>Dni Alumno:</label><input type="text" id="dni" name="dni"><br/>
                    <?php $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label><?php echo e($a->getNombre()); ?></label>
                        <input type="checkbox" name="asignaturas[]" id="asignaturas[]" value=<?php echo e($a->getId()); ?>/><!--Esto funciona-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br/>
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <div>
                <h2>Mostrar Matricula</h2>
                <form action="showMatr" method="post">
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <?php if(isset($matriculas)): ?>
                <ul>
                    <?php $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($m); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\angel\Desktop\Repositorios\Angel_AED_PGL\AED\laravel\MiniDriveConDAO\resources\views/Matricula.blade.php ENDPATH**/ ?>