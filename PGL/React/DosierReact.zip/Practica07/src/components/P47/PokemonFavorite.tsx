import React from 'react'

type Props = {}

const PokemonFavorite = (props: Props) => {
  return (
    <div>PokemonFavorite</div>
  )
}

export default PokemonFavorite