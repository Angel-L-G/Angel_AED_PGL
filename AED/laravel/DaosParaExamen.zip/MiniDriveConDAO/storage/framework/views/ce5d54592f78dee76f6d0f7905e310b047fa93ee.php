<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">

    </head>
    <body class="antialiased">
        <div class="container">
            <div class="form-container">
                <form action="LogIn" method="post">
                    <?php echo csrf_field(); ?>
                    <label class="form-label">Id</label>
                    <input type="text" name="id" required>
                    <br/>
                    <label class="form-label">Name</label>
                    <input type="text" name="name" required>
                    <br/>
                    <label class="form-label">password</label>
                    <input type="password" name="psswrd" required>
                    <br/><br/>
                    <button type="submit" class="form-button">Log In</button>
                </form>
            </div>
            <a href="/showRegister">Registrate</a>
        </div>

    </body>
</html>
<?php /**PATH C:\Users\angel\Desktop\Repositorios\Angel_AED_PGL\AED\laravel\MiniDriveConDAO\resources\views/Login.blade.php ENDPATH**/ ?>