import { StyleSheet } from "react-native";

const stylesPractica8 = StyleSheet.create({

})