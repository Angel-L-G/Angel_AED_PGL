<?php
    namespace App\Contracts;

    class AsignaturaContract{
        public const TABLE_NAME="asignaturas";
        public const COL_ID="id";
        public const COL_NOMBRE="nombre";
        public const COL_CURSO="curso";
    }
?>
