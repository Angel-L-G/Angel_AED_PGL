import React from 'react'

type Props = {}

const Partida = (props: Props) => {
    return (
        <div>Partida</div>
    )
}

export default Partida