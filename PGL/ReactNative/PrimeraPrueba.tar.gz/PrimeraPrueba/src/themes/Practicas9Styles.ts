import { StyleSheet } from "react-native";

const stylesPractica9 = StyleSheet.create({
    botonesJuntos: {
        flexDirection: "row",
        gap: 23,
        justifyContent: "center"
    }
})

export default stylesPractica9