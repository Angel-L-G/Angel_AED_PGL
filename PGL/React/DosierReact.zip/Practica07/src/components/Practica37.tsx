import React from 'react'

type Props = {}

const Practica37 = (props: Props) => {
    /*<ReactPlayer
        url="http://allzic06.ice.infomaniak.ch/allzic06"
        controls
        width="400px"
        height="20px"
    />*/

  return (
    <div className='container'>
        
    </div>
  )
}

export default Practica37