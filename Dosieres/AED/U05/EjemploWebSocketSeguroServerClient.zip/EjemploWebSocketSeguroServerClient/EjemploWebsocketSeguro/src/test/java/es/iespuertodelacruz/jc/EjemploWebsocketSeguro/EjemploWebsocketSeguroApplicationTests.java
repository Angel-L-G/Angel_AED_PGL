package es.iespuertodelacruz.jc.EjemploWebsocketSeguro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploWebsocketSeguroApplicationTests {

	@Test
	void contextLoads() {
	}

}
