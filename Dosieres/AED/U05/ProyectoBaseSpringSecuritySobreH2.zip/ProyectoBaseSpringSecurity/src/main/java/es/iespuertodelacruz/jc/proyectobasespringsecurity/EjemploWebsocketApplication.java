package es.iespuertodelacruz.jc.proyectobasespringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploWebsocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploWebsocketApplication.class, args);
	}

}
