package es.iespto.angel.gente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
