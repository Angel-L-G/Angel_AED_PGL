package es.iepto.angel.peliculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculasApplicationTests {

	@Test
	void contextLoads() {
	}

}
