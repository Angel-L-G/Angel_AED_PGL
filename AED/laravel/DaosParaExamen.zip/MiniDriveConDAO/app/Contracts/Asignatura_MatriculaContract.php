<?php
    namespace App\Contracts;
    
    class Asignatura_MatriculaContract{
        public const TABLE_NAME="asignatura_matricula";
        public const COL_ID="id";
        public const COL_ID_MATRICULA="idmatricula";
        public const COL_ID_ASIGNATURA="idasignatura";
    }
?>