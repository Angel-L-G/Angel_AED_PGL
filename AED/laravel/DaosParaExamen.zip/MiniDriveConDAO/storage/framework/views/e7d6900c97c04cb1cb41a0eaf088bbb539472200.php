<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">

    </head>
    <body class="antialiased">
        <div class="container">
            <div>
                <h2>Agregar Asignatura</h2>
                <form action="createAsig" method="post">
                    <label>Nombre:</label><input type="text" id="nombre" name="nombre"><br/>
                    <label>Curso:</label><input type="text" id="curso" name="curso"><br/>
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <div>
                <h2>Borrar Asignatura</h2>
                <form action="deleteAsig" method="post">
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <div>
                <h2>Editar Asignatura</h2>
                <form action="updateAsig" method="post">
                    <label>Nombre:</label><input type="text" id="nombre" name="nombre"><br/>
                    <label>Curso:</label><input type="text" id="curso" name="curso"><br/>
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <div>
                <h2>Mostrar Asignatura</h2>
                <form action="showAsig" method="post">
                    <label>Id:</label><input type="text" id="id" name="id"><br/>
                    <input type="submit" value="enviar">
                </form>
            </div>
            <?php if(isset($asignaturas)): ?>
                <ul>
                    <?php $__currentLoopData = $asignaturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($a); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\angel\Desktop\Repositorios\Angel_AED_PGL\AED\laravel\MiniDriveConDAO\resources\views/Asignaturas.blade.php ENDPATH**/ ?>