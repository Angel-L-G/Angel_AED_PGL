import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Practica29 = (props: Props) => {
    return (
        <View>
            <Text>Practica29</Text>
        </View>
    )
}

export default Practica29

const styles = StyleSheet.create({})