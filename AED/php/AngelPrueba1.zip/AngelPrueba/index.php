<?php
    require("app/Router.php");

    Router::init();

?>