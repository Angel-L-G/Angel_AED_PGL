<?php
    class Result{
        public static function generateRes(){
            echo "<!DOCTYPE html>";
            echo "<html lang='en'>";
            echo "<head>";
                echo "<meta charset='UTF-8'>";
                echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
                echo "<title>Resultados</title>";
            echo "</head>";
            echo "<body>";
                    
                $fileGuess = "app/model/Guess.dat";
                $fileRand = "app/model/Rand.dat"; 

                $sGuesess = file_get_contents($fileGuess);
                $guesses = unserialize($sGuesess);

                $sRand = file_get_contents($fileRand);
                $rand = unserialize($sRand);

                

            echo "</body>";
            echo "</html>";
        }
    }
?>