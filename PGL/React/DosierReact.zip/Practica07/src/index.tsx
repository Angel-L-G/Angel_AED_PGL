import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';

/*import App from './components/App';
import EjEffect from './components/EjEffect';
import ComponenteApp from './components/ComponenteApp';
import Contador from './components/Practica8';
import Tabla from './components/Practica9';
import Practica10 from './components/Practica10';
import ComponenteEstatico from "./components/Practica11";
import Practica12 from './components/Practica12';
import Practica13 from './components/Practica13';
import Practica14 from './components/Practica14';
import Practica15 from './components/Practica15';
import Practica16 from './components/Practica16';
import Practica17 from './components/Practica17';
import Practica18 from './components/Practica18';
import Practica19 from './components/Practica19';
import Practica20 from './components/Practica20';
import Practica21 from './components/Practica21';
import Practica22 from './components/Practica22';
import Practica23 from './components/Practica23';
import Practica24 from './components/Practica24';
import Practica25 from './components/Practica25';
import Practica26 from './components/Practica26';
import Practica27 from './components/Practica27';
import Practica28 from './components/Practica28';
import Practica29 from './components/Practica29';
import Practica30 from './components/Practica30';
import Practica31 from './components/P31/Practica31';
import Practica32 from './components/Practica32';
import Practica33 from './components/Practica33';*/

import Practica35 from './components/P35/Practica35';
import Practica36 from './components/P36/Practica36';

import Practica38 from './components/P38/Practica38';

import Practica40 from './components/P40-(PokeApi)/ListPokemonCard';

import ApiCapitales from './components/Adicional2';
import Practica42 from './components/P42/Practica42';
import Practica43 from './components/P43/Practica43';
import Practica44 from './components/P44/Practica44';

import Practica47 from './components/P47/Practica47';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <Practica47 />
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
