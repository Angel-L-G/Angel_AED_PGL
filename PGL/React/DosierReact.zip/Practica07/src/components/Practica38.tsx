import React from 'react'

type Props = {}

const Practica38 = (props: Props) => {
  return (
    <div className='container'>
        
    </div>
  )
}

export default Practica38