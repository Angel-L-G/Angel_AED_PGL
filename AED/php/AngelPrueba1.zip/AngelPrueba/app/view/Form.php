<?php
    class Form{
        public static function generateForm(){
            echo "<!DOCTYPE html>";
            echo "<html lang='en'>";
            echo "<head>";
                echo "<meta charset='UTF-8'>";
                echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
                echo "<title>Intento</title>";
            echo "</head>";
            echo "<body>";
                    
                echo "<form action='adivinar/mostrarResultados' method='post'>";
                    echo "<input type='number' name='guess' id='guess' placeholder='Numero a Adivinar'>";
                    //echo "";
                    echo "<input type='submit' value='enviar'>";
                echo "</form>";

                rand(1,10);

                $fileRand = "app/model/Rand.dat";

                $sRandNum = file_get_contents($fileRand);
                $randNum = unserialize($sRandNum)?? -1;

                if($randNum < 0){
                    rand(1,10);

                    $sRandNum = serialize($randNum);
                   file_put_contents($fileRand, $sRandNum);
                }

            echo "</body>";
            echo "</html>";
        }
    }
?>

