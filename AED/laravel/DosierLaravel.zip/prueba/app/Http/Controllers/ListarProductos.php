<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ListarProductos extends Controller
{
    public static function listar(){
        echo " - Estoy en Listar Ahora";
    }
}
