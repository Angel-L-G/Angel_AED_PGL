<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body class="antialiased">
    @php
        $dato = time()
    @endphp
    
    <p>Desde el 1-01-1970 han pasado: {{$dato}} segundos</p>
    </body>
</html>
