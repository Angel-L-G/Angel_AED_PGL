package es.iespuertodelacruz.jc.ejemplowebsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploWebsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
